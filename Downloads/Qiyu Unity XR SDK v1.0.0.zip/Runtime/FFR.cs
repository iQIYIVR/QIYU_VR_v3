﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

namespace Unity.XR.Qiyu
{
    public enum EFoveationLevel
    {
        None = -1,
        Low = 0,
        Med = 1,
        High = 2
    }

    public static partial class Utils
    {
        public static void SetFoveationLevel(int level)
        {
            NativeMethods.SetFoveationLevel(level);
        }

        public static int GetFoveationLevel()
        {
            int ret = NativeMethods.GetFoveationLevel();
            return ret;
        }

        
        public static void SetFoveationParamets(float foveationGainX, float foveationGainY, float foveationArea, float foveationMinimum)
        {
            NativeMethods.SetFoveationParamets(foveationGainX, foveationGainY, foveationArea, foveationMinimum);
        }

        /// <summary>
        /// Update Inter Pupil Distance from system
        /// </summary>
        public static float TryUpdateIPD()
        {
            return NativeMethods.UpdateIPD();
        }
    }
}
