﻿//=============================================================================
//
//          Copyright (c) 2021 Beijing iQIYI Intelligent Technologies Inc.
//                          All Rights Reserved.
//
//=============================================================================
using UnityEngine;

namespace Unity.XR.Qiyu
{
    sealed class QiyuRecenter : MonoBehaviour
    {
        public const string TAG = "RecenterView";

        Material mat;
        private Transform recenterTR;
        bool showRecenter = false;
        float recenterTime = 1;
        float escapeTime = 0;

        bool isRecenterDelayTime = false;
        float recenterDelayTime = 0.5f;
        bool isBKeyDown = false; //B键按下
        bool keyHomeAndKeyBCross = false;//B键和Home键有重叠

        private void Awake()
        {
            recenterTR = transform.Find("Recenter");
            recenterTR.Find("bg").GetComponent<MeshRenderer>().sortingOrder = 2;
            recenterTR.Find("tr/path").GetComponent<MeshRenderer>().sortingOrder = 2;
            mat = recenterTR.Find("tr/path").GetComponent<MeshRenderer>().sharedMaterial;
        }

        void Update()
        {
            if (QiyuInput.GetDown(QiyuInput.VirtualButton.B, QiyuInput.Controller.RTouch))
            {
                isBKeyDown = true;
                if (isRecenterDelayTime)
                    keyHomeAndKeyBCross = true;
            }
            if (QiyuInput.GetDown(QiyuInput.VirtualButton.Home, QiyuInput.Controller.RTouch))
            {
                isRecenterDelayTime = true;
                if (isBKeyDown)
                    keyHomeAndKeyBCross = true;
            }
            if (QiyuInput.GetUp(QiyuInput.VirtualButton.B, QiyuInput.Controller.RTouch))
            {
                isBKeyDown = false;
                if (!isRecenterDelayTime)
                    keyHomeAndKeyBCross = false;
            }
            if (isRecenterDelayTime && !keyHomeAndKeyBCross)
            {
                if (QiyuInput.GetUp(QiyuInput.VirtualButton.Home, QiyuInput.Controller.RTouch))
                {
                    isRecenterDelayTime = false;
                    escapeTime = 0;
                    //Debug.Log("QVR_SendHomeEvent");
                    //QiyuPlugin.QiyuSDKCorePlugins.QVR_SendHomeEvent();
                }

                escapeTime += Time.deltaTime;
                float factor = escapeTime / recenterDelayTime;
                if (factor >= 1)
                {
                    isRecenterDelayTime = false;
                    mat.SetFloat("_Angle", 361);
                    showRecenter = true;
                    escapeTime = 0;
                }
            }
            if (keyHomeAndKeyBCross)
            {
                showRecenter = false;
                escapeTime = 0;
            }

            recenterTR.gameObject.SetActive(showRecenter);

            if (QiyuInput.GetUp(QiyuInput.VirtualButton.Home, QiyuInput.Controller.RTouch))
            {
                isRecenterDelayTime = false;
                showRecenter = false;
                escapeTime = 0;
                if (!isBKeyDown)
                    keyHomeAndKeyBCross = false;
            }
            if (showRecenter)
            {
                if (QiyuInput.GetDown(QiyuInput.VirtualButton.Trigger, QiyuInput.Controller.RTouch))
                {
                    showRecenter = false;
                    escapeTime = 0;
                }
            }

            if (showRecenter)
            {
                escapeTime += Time.deltaTime;
                float factor = escapeTime / recenterTime;

                float angle = Mathf.Lerp(361, 0, factor);
                mat.SetFloat("_Angle", angle);
                if (factor > 1)
                {
                    showRecenter = false;
                    mat.SetFloat("_Angle", 0);
                    factor = 0;
                    Recenter();
                }
            }
        }

        public void Recenter()
        {
            QiyuManager.Instance.Recenter();
        }

        Vector3 localPos = new Vector3(0, 0, 2);
        private void LateUpdate()
        {
            if (Camera.main == null)
                return;

            this.transform.position = Camera.main.transform.TransformPoint(localPos);
            this.transform.forward = Camera.main.transform.forward;
        }
    }
}