﻿//=============================================================================
//
//          Copyright (c) 2021 Beijing iQIYI Intelligent Technologies Inc.
//                          All Rights Reserved.
//
//=============================================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using FunPtr = System.IntPtr;
using DataPtr = System.IntPtr;
using StringPtr = System.IntPtr;
using System;

namespace Unity.XR.Qiyu
{
    public static partial class QiyuPlugin
    {
        public static bool GetBoundaryConfigured()
        {
            return QiyuSDKCorePlugins.QVR_GetBoundaryConfigured() == Bool.True;
        }

        public static BoundaryTestResult TestBoundaryPoint(Vector3f point, BoundaryType boundaryType)
        {
            return QiyuSDKCorePlugins.QVR_TestBoundaryPoint(point, boundaryType);
        }

        public static void GetOriginAxis(ref Vector3f pos, ref Quatf rot)
        {
            QiyuSDKCorePlugins.QVR_GetOriginAxis(ref pos, ref rot);
        }

        public static bool GetBoundaryGeometry(BoundaryType boundaryType, DataPtr points, ref int pointsCount)
        {
            return QiyuSDKCorePlugins.QVR_GetBoundaryGeometry(boundaryType, points, ref pointsCount) == Bool.True;
        }

        public static Vector3f GetBoundaryDimensions(BoundaryType boundaryType)
        {
            return QiyuSDKCorePlugins.QVR_GetBoundaryDimensions(boundaryType);
        }

        public static bool GetBoundaryVisible()
        {
            return QiyuSDKCorePlugins.QVR_GetBoundaryVisible() == Bool.True;
        }

        public static bool SetBoundaryVisible(bool value)
        {
            return QiyuSDKCorePlugins.QVR_SetBoundaryVisible(ToBool(value)) == Bool.True;
        }

        public static void RegisterBoundaryChangedCallback(FunPtr callBack)
        {
            QiyuSDKCorePlugins.QVR_RegisterBoundaryChangedCallback(callBack);
        }

        public static void UnRegisterBoundaryChangedCallback(FunPtr callBack)
        {
            QiyuSDKCorePlugins.QVR_UnRegisterBoundaryChangedCallback(callBack);
        }

        public static void TestMessageCallBack(string param, RequestCallback callback)
        {
            QiyuSDKCorePlugins.QVR_TestMessageCallBack(QiyuMessageManager.AddRequest(callback), param);
        }

        public static string TestString(string param)
        {
            return QiyuSDKCorePlugins.QVR_TestString(param);
        }

        /// <summary>
        /// 初始化SDK
        /// </summary>
        /// <param name="app_id">APPID</param>
        /// <param name="developer_id">DeveloperID</param>
        /// <param name="app_secret">App 秘钥</param>
        /// <param name="sign_key">App 接口签名Key</param>
        public static void InitQiyuSDK(string app_id, string developer_id, string app_secret, string sign_key)
        {
            QiyuSDKCorePlugins.QVR_InitQiyuSDK(app_id, developer_id, app_secret, sign_key);
        }
        /// <summary>
        /// 获取Qiyu账户是否登录
        /// </summary
        public static bool IsQiyuAccountLogin()
        {
            return QiyuSDKCorePlugins.QVR_IsAccountLogin() == (int)Bool.True;
        }
        /// <summary>
        /// 获取Qiyu账户信息
        /// </summary>
        /// <param name="callback">请求的回调函数</param>
        public static void GetQiyuAccountInfo(RequestCallback callback)
        {
            QiyuSDKCorePlugins.QVR_GetQiyuAccountInfo(QiyuMessageManager.AddRequest(callback));
        }

        /// <summary>
        /// 打开其他应用
        /// </summary>
        /// <param name="app_id">应用id</param>
        /// <param name="key">深度连接Key</param>
        /// <param name="value">深度连接value</param>
        public static void LaunchOtherApp(string app_id, string key, string value)
        {
            QiyuSDKCorePlugins.QVR_LaunchOtherApp(app_id, key, value);
        }
        /// <summary>
        /// 打开Home
        /// </summary>
        /// <param name="key">深度连接Key</param>
        /// <param name="value">深度连接value</param>
        public static void LaunchHome(string key, string value)
        {
            QiyuSDKCorePlugins.QVR_LaunchHome(key, value);
        }
        /// <summary>
        /// 获取DLC更新信息
        /// </summary>
        /// <param name="app_id">AppID</param>
        /// <param name="curVersion">当前应用版本</param>
        /// <param name="callback">回调函数</param>
        public static void GetAppUpdateInfo(string app_id, string curVersion, RequestCallback callback)
        {
            QiyuSDKCorePlugins.QVR_GetAppUpdateInfo(QiyuMessageManager.AddRequest(callback), app_id, curVersion);
        }

        /// <summary>
        /// 获取深度连接信息
        /// </summary>
        /// <param name="callback">回调函数</param>
        public static void GetDeepLink(RequestCallback callback)
        {
            QiyuSDKCorePlugins.QVR_GetDeepLink(QiyuMessageManager.AddRequest(callback));
        }

        /// <summary>
        /// 获取地面高度
        /// </summary>
        public static float GetFloorLevel()
        {
            if (!QiyuPlatform.IsAndroid)
                return 0;

            return QiyuSDKCorePlugins.QVR_GetFloorLevel();
        }

        /// <summary>
        /// 获取用户瞳距设置
        /// </summary>
        public static float GetUserIPD()
        {
            if (!QiyuPlatform.IsAndroid)
                return 0;

            return QiyuSDKCorePlugins.QVR_GetUserIPD() * 1.0f / 1000;
        }
    }
}
