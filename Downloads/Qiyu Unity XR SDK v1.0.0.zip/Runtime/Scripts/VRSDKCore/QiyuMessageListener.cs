﻿//=============================================================================
//
//          Copyright (c) 2021 Beijing iQIYI Intelligent Technologies Inc.
//                          All Rights Reserved.
//
//=============================================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Unity.XR.Qiyu
{
    public enum MessageCode : uint
    {
        QiyuSdkInit,  //奇遇初始化返回结果
        End,
    }

    public class MessageResultCode
    {
        public static string S0000 = "S0000";//正常
        public static string S9000 = "S9000";//系统异常
        public static string S8001 = "S8001";//账号未登陆 
        public static string S8002 = "S8002";//未连接到Service
    }

    public class QiyuMessageListener
    {
        private static readonly string TAG = "QiyuMessageListener";

        public delegate void EventCallBack(params object[] args);

        public static void AddListener(MessageCode messageCode, EventCallBack callback)
        {
            EventCallBack current = null;
            listeners.TryGetValue((int)messageCode, out current);
            if (current != null)
            {
                listeners[(int)messageCode] = current + callback;
            }
            else
            {
                listeners[(int)messageCode] = callback;
            }
        }

        public static void RemoveListener(MessageCode messageCode, EventCallBack callback)
        {
            EventCallBack current = null;
            listeners.TryGetValue((int)messageCode, out current);
            if (current != null)
            {
                listeners[(int)messageCode] = current - callback;
            }
        }

        public static void Trigger(MessageCode messageCode, params object[] args)
        {
            EventCallBack current = null;
            listeners.TryGetValue((int)messageCode, out current);
            if (current != null)
            {
                foreach (var single in current.GetInvocationList())
                {
                    try
                    {
                        ((EventCallBack)single)(args);
                    }
                    catch (System.Exception e)
                    {
                        Debug.LogError(TAG + e.ToString());
                    }
                }
            }
        }

        private static Dictionary<int, EventCallBack> listeners = new Dictionary<int, EventCallBack>();
    }
}