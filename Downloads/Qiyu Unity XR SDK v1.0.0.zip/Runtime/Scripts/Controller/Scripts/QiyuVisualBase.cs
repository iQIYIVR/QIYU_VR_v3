﻿//=============================================================================
//
//          Copyright (c) 2021 Beijing iQIYI Intelligent Technologies Inc.
//                          All Rights Reserved.
//
//=============================================================================
using System;
using UnityEngine;
namespace Unity.XR.Qiyu
{
    public class QiyuVisualBase : MonoBehaviour
    {
        /// <summary>
        /// 左右手
        /// </summary>
        public enum Hand
        {
            L,
            R
        };

        public Hand _hand = Hand.L;

        private void Start()
        {
            //Modify Ray Offset
            if (_hand == Hand.L)
            {
                var LeftHandRay = GameObject.Find("[LeftHand Controller] Original Attach");
                if (LeftHandRay)
                {
                    LeftHandRay.transform.localPosition = new Vector3(0, -0.033f, -0.022f);
                    LeftHandRay.transform.localEulerAngles = new Vector3(40, 0, 0);
                }
            }
            else if (_hand == Hand.R)
            {
                var RightHandRay = GameObject.Find("[RightHand Controller] Original Attach");
                if (RightHandRay)
                {
                    RightHandRay.transform.localPosition = new Vector3(0, -0.033f, -0.022f);
                    RightHandRay.transform.localEulerAngles = new Vector3(40, 0, 0);
                }
            }
        }
    }
}
