﻿//=============================================================================
//
//          Copyright (c) 2021 Beijing iQIYI Intelligent Technologies Inc.
//                          All Rights Reserved.
//
//=============================================================================
using UnityEngine;

namespace Unity.XR.Qiyu
{
    public class QiyuControllerVisual : QiyuVisualBase
    {
        public static float COLOR_FACTOR_ON = 0.7f;
        public static float GRIP_FORCE_LIMIT_R = -7.0f;
        public static float GRIP_FORCE_LIMIT_L = 7.0f;
        public static float TRIGGER_FORCE_LIMIT = 15;
        public static Vector3 BUTTON_DOWN_POS1 = new Vector3(0, -0.02f, 0);
        public static Vector3 BUTTON_DOWN_POS2 = new Vector3(0, -0.01f, 0);
        public static float JOYSTICK_ANGLE_LIMIT = 20.0f;

        private Transform handleTrans;
        public MeshRenderer bodyMR;

        public Transform homeTrans;
        public MeshRenderer homeMR;

        public Transform aTrans;
        public MeshRenderer aMR;

        public Transform bTrans;
        public MeshRenderer bMR;

        public Transform gripTrans;
        public MeshRenderer gripMR;

        public Transform triggerTrans;
        public MeshRenderer triggerMR;

        public Transform joyStickTrans;
        public MeshRenderer joyStickMR;

        public Material matNormal;

        void Awake()
        {
            handleTrans = this.transform;

            Transform handle = handleTrans.Find("Handle");
            bodyMR = handle.Find("Body").GetComponent<MeshRenderer>();

            homeTrans = handle.Find("BtnHome/BtnHome");
            homeMR = homeTrans.GetComponent<MeshRenderer>();

            aTrans = handle.Find("BtnA/BtnA");
            aMR = aTrans.GetComponent<MeshRenderer>();

            bTrans = handle.Find("BtnB/BtnB");
            bMR = bTrans.GetComponent<MeshRenderer>();

            gripTrans = handle.Find("BtnGrip/BtnGrip");
            gripMR = gripTrans.GetComponent<MeshRenderer>();

            triggerTrans = handle.Find("BtnTrigger/BtnTrigger");
            triggerMR = triggerTrans.GetComponent<MeshRenderer>();

            joyStickTrans = handle.Find("BtnJoyStick/BtnJoyStick");
            joyStickMR = joyStickTrans.GetComponent<MeshRenderer>();

            InitMats();
        }

        private void OnEnable()
        {
            Debug.Log("[qc][Visual] OnEnable");
            QiyuEvent.AddListener(QiyuEventType.DEVICE_INPUT_EVENT, CONTROLLER_EVENT);
        }

        private void OnDisable()
        {
            Debug.Log("[qc][Visual] OnDisable");
            QiyuEvent.RemoveListener(QiyuEventType.DEVICE_INPUT_EVENT, CONTROLLER_EVENT);
        }

        void CONTROLLER_EVENT(params object[] args)
        {
            QiyuInput.Controller controller = (QiyuInput.Controller)args[0];
            QiyuInput.VirtualButton virtualButton = (QiyuInput.VirtualButton)args[1];
            QiyuInput.ButtonAction buttonAction = (QiyuInput.ButtonAction)args[2];
            //Debug.LogFormat("CONTROLLER_EVENT:{0},{1},{2}", controller, virtualButton, buttonAction);
            if ((controller == QiyuInput.Controller.LTouch && _hand == Hand.L)
                || (controller == QiyuInput.Controller.RTouch && _hand == Hand.R)
                )
            {
                switch (args[1])
                {
                    case QiyuInput.VirtualButton.Home:
                        if (buttonAction == QiyuInput.ButtonAction.Down)
                            SetHomeBtnOn();
                        else if (buttonAction == QiyuInput.ButtonAction.Up)
                            SetHomeBtnOff();
                        break;
                    case QiyuInput.VirtualButton.Trigger:
                        if (buttonAction == QiyuInput.ButtonAction.Down)
                            SetTriggerOn();
                        else if (buttonAction == QiyuInput.ButtonAction.Up)
                            SetTriggerOff();
                        break;
                    case QiyuInput.VirtualButton.Grip:
                        if (buttonAction == QiyuInput.ButtonAction.Down)
                            SetGripOn();
                        else if (buttonAction == QiyuInput.ButtonAction.Up)
                            SetGripOff();
                        break;
                    case QiyuInput.VirtualButton.A:
                        if (buttonAction == QiyuInput.ButtonAction.Down)
                            SetABtnOn();
                        else if (buttonAction == QiyuInput.ButtonAction.Up)
                            SetABtnOff();
                        break;
                    case QiyuInput.VirtualButton.B:
                        if (buttonAction == QiyuInput.ButtonAction.Down)
                            SetBBtnOn();
                        else if (buttonAction == QiyuInput.ButtonAction.Up)
                            SetBBtnOff();
                        break;
                }
            }
        }

        void InitMats()
        {
            aMR.materials[0] = matNormal;
            bMR.materials[0] = matNormal;
            triggerMR.materials[0] = matNormal;
            joyStickMR.materials[0] = matNormal;
            gripMR.materials[0] = matNormal;
            homeMR.materials[0] = matNormal;
        }

        [ContextMenu("SetABtnOn")]
        public void SetABtnOn()
        {
            Debug.Log("[qc][Visual]SetAppBtnOn");
            aMR.sharedMaterial.SetFloat("_Type", COLOR_FACTOR_ON);
            aTrans.localPosition = BUTTON_DOWN_POS1;
        }

        [ContextMenu("SetABtnOff")]
        public void SetABtnOff()
        {
            Debug.Log("[qc][Visual]SetAppBtnOff");
            aMR.sharedMaterial.SetFloat("_Type", 1);
            aTrans.localPosition = Vector3.zero;
        }

        [ContextMenu("SetBBtnOn")]
        public void SetBBtnOn()
        {
            Debug.Log("[qc][Visual]SetAppBtnOn");
            bMR.sharedMaterial.SetFloat("_Type", COLOR_FACTOR_ON);
            bTrans.localPosition = BUTTON_DOWN_POS1;
        }

        [ContextMenu("SetBBtnOff")]
        public void SetBBtnOff()
        {
            Debug.Log("[qc][Visual]SetAppBtnOff");
            bMR.sharedMaterial.SetFloat("_Type", 1);
            bTrans.localPosition = Vector3.zero;
        }

        [ContextMenu("SetGripOn")]
        public void SetGripOn()
        {
            Debug.Log("[qc][Visual]SetGripOn");
            gripMR.sharedMaterial.SetFloat("_Type", COLOR_FACTOR_ON);
        }

        [ContextMenu("SetGripOff")]
        public void SetGripOff()
        {
            Debug.Log("[qc][Visual]SetGripOff");
            gripMR.sharedMaterial.SetFloat("_Type", 1);
        }

        [ContextMenu("SetHomeBtnOn")]
        public void SetHomeBtnOn()
        {
            Debug.Log("[qc][Visual]SetHomeBtnOn");
            homeMR.sharedMaterial.SetFloat("_Type", COLOR_FACTOR_ON);
            homeTrans.localPosition = BUTTON_DOWN_POS2;
        }

        [ContextMenu("SetHomeBtnOff")]
        public void SetHomeBtnOff()
        {
            Debug.Log("[qc][Visual]SetHomeBtnOff");
            homeMR.sharedMaterial.SetFloat("_Type", 1);
            homeTrans.localPosition = Vector3.zero;
        }

        [ContextMenu("SetTriggerOn")]
        public void SetTriggerOn()
        {
            Debug.Log("[qc][Visual]SetTriggerOn");
            triggerMR.sharedMaterial.SetFloat("_Type", COLOR_FACTOR_ON);
        }

        [ContextMenu("SetTriggerOff")]
        public void SetTriggerOff()
        {
            Debug.Log("[qc][Visual]SetTriggerOff");
            triggerMR.sharedMaterial.SetFloat("_Type", 1);
        }

        [ContextMenu("SetJoyStickOn")]
        public void SetJoyStickOn()
        {
            Debug.Log("[qc][Visual]SetTriggerOn");
            joyStickMR.sharedMaterial.SetFloat("_Type", COLOR_FACTOR_ON);
            joyStickTrans.localPosition = BUTTON_DOWN_POS1;
        }

        [ContextMenu("SetJoyStickOff")]
        public void SetJoyStickOff()
        {
            Debug.Log("[qc][Visual]SetTriggerOff");
            joyStickMR.sharedMaterial.SetFloat("_Type", 1);
            joyStickTrans.localPosition = Vector3.zero;
        }

        public void LateUpdate()
        {
            //Debug.Log("[qc][Visual]OnUpdateStatus:" + (int)args[0]);
            if (_hand == Hand.L)
            {
                SetTriggerForce(QiyuInput.GetTriggerForce(QiyuInput.Controller.LTouch));
                SetGripForce(QiyuInput.GetGripForce(QiyuInput.Controller.LTouch));
            }
            else
            {
                SetTriggerForce(QiyuInput.GetTriggerForce(QiyuInput.Controller.RTouch));
                SetGripForce(QiyuInput.GetGripForce(QiyuInput.Controller.RTouch));
            }
            //Debug.Log(string.Format("_hand:{0},handleTrans:{1}", _hand, handleTrans.position));
            SetJoyStick();
        }

        public void SetTriggerForce(float force)
        {
            float factor = force / 10.0f;
            float value = Mathf.Lerp(0, TRIGGER_FORCE_LIMIT, factor);
            triggerTrans.localEulerAngles = new Vector3(value, 0, 0);
        }

        public void SetGripForce(float force)
        {
            float factor = force / 10.0f;
            float value = Mathf.Lerp(0, _hand == Hand.L ? GRIP_FORCE_LIMIT_L : GRIP_FORCE_LIMIT_R, factor);
            gripTrans.localEulerAngles = new Vector3(0, value, 0);
        }

        public void SetJoyStick()
        {
            Vector2 pos;
            bool isDown;
            if (_hand == Hand.L)
            {
                pos = QiyuInput.GetJoyStickPosition(QiyuInput.Controller.LTouch);
                isDown = QiyuInput.GetRawDown(QiyuInput.VirtualButton.JoyStick, QiyuInput.Controller.LTouch);
            }
            else
            {
                pos = QiyuInput.GetJoyStickPosition(QiyuInput.Controller.RTouch);
                isDown = QiyuInput.GetRawDown(QiyuInput.VirtualButton.JoyStick, QiyuInput.Controller.RTouch);
            }

            if (pos.sqrMagnitude > 550f || isDown)
                joyStickMR.sharedMaterial.SetFloat("_Type", COLOR_FACTOR_ON);
            else
                joyStickMR.sharedMaterial.SetFloat("_Type", 1);

            if (isDown)
                joyStickTrans.localPosition = BUTTON_DOWN_POS1;
            else
                joyStickTrans.localPosition = Vector3.zero;

            float factorXAngle = (pos.y + 1.0f) / 2.0f;
            factorXAngle = factorXAngle < 0 ? 0 : factorXAngle;
            float xAnagle = Mathf.Lerp(-JOYSTICK_ANGLE_LIMIT, JOYSTICK_ANGLE_LIMIT, factorXAngle);

            float factorZAngle = (pos.x + 1.0f) / 2.0f;
            factorZAngle = factorZAngle < 0 ? 0 : factorZAngle;
            float zAnagle = Mathf.Lerp(JOYSTICK_ANGLE_LIMIT, -JOYSTICK_ANGLE_LIMIT, factorZAngle);
            joyStickTrans.localEulerAngles = new Vector3(xAnagle, 0, zAnagle);
        }
    }
}