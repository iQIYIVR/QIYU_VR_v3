﻿//=============================================================================
//
//          Copyright (c) 2021 Beijing iQIYI Intelligent Technologies Inc.
//                          All Rights Reserved.
//
//=============================================================================
namespace Unity.XR.Qiyu
{
    public static class QiyuInputConst
    {
        public static readonly float CONTROLLER_TOUCHPOINT_SCALER = 0.013f;
    }
}