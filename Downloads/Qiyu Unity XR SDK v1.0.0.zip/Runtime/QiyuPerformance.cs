﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.XR;
using System.Runtime.InteropServices;
using XRStats = UnityEngine.XR.Provider.XRStats;

namespace Unity.XR.Qiyu
{
    
    public static class Performance
    {
        /// <summary>
        /// Set the CPU Level for the device
        /// </summary>
        /// <param name="level">
        /// Allowable values are integers in the range 0 - 4 (inclusive). A value of 0 is the lowest performance level but is the most power efficient.
        /// </param>
        /// <returns>
        /// True if we have no errors returned by the native function. We return false when the native function returns a failure condition. Check 
        /// the log for more information.
        /// </returns>
        public static void TrySetCPULevel(int level)
        {
            NativeMethods.SetCPULevel(level);
        }

        /// <summary>
        /// Set the GPU performance level 
        /// </summary>
        /// <param name="level"> 
        /// Allowable values are integers in the range 0 - 4 (inclusive). A value of 0 is the lowest performance level but is the most power efficient.
        /// </param>
        /// <returns>
        /// True if we have no errors returned by the native function. We return false when the native function returns a failure condition. Check 
        /// the log for more information.
        /// </returns>
        public static void TrySetGPULevel(int level)
        {
            NativeMethods.SetGPULevel(level);            
        }

        

    }

}