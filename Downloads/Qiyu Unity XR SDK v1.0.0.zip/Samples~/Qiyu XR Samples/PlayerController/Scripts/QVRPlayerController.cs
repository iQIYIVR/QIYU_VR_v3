﻿//=============================================================================
//
//          Copyright (c) 2021 Beijing iQIYI Intelligent Technologies Inc.
//                          All Rights Reserved.
//
//=============================================================================

using System;
using Unity.XR.Qiyu;
using UnityEngine;
using UnityEngine.InputSystem.XR;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;


[RequireComponent(typeof(CharacterController))]
public class QVRPlayerController : MonoBehaviour
{
    private string TAG = "QVRPlayerController";

    /// <summary>
    /// The rate acceleration during movement.
    /// </summary>
    public float Acceleration = 0.1f;

    /// <summary>
    /// The rate of damping on movement.
    /// </summary>
    public float Damping = 0.3f;

    /// <summary>
    /// The rate of additional damping when moving sideways or backwards.
    /// </summary>
    public float BackAndSideDampen = 0.5f;

    [Tooltip("How many fixed speeds to use with linear movement? 0=linear control")]
    public int FixedSpeedSteps;
    public float GravityModifier = 0.379f;
    public bool EnableLinearMovement = true;
    public bool EnableRotation = true;
    protected CharacterController Controller = null;
    private XRRig CameraRig = null;
    private float MoveScale = 1.0f;
    private Vector3 MoveThrottle = Vector3.zero;
    private float FallSpeed = 0.0f;
    private float MoveScaleMultiplier = 1.0f;
    private float SimulationRate = 60f;

    public CharacterTrackedPoseDriver characterTrackedPoseDriver;

    void Start()
    {

    }

    void Awake()
    {
        Controller = gameObject.GetComponent<CharacterController>();

        if (Controller == null)
            Debug.LogWarning(TAG + ": No CharacterController attached.");

        XRRig[] CameraRigs = gameObject.GetComponentsInChildren<XRRig>();

        if (CameraRigs.Length == 0)
            Debug.LogWarning(TAG + ": No XRRig attached.");
        else if (CameraRigs.Length > 1)
            Debug.LogWarning(TAG + ": More then 1 XRRig attached.");
        else
            CameraRig = CameraRigs[0];
    }

    void OnEnable()
    {
        characterTrackedPoseDriver.UpdatedAnchors += UpdatedAnchors;
    }

    void OnDisable()
    {
        characterTrackedPoseDriver.UpdatedAnchors -= UpdatedAnchors;
    }

    void Update()
    {
        UpdateController();
    }

    protected virtual void UpdatedAnchors()
    {
        if (EnableRotation)
        {
            Transform root = Camera.main.transform;

            Vector3 prevPos = root.position;
            Quaternion prevRot = root.rotation;

            transform.rotation = Quaternion.Euler(0.0f, root.rotation.eulerAngles.y, 0.0f);

            root.position = prevPos;
            root.rotation = prevRot;
        }
    }


    protected virtual void UpdateController()
    {        
        UpdateMovement();

        Vector3 moveDirection = Vector3.zero;

        float motorDamp = (1.0f + (Damping * SimulationRate * Time.deltaTime));

        MoveThrottle.x /= motorDamp;
        MoveThrottle.y = (MoveThrottle.y > 0.0f) ? (MoveThrottle.y / motorDamp) : MoveThrottle.y;
        MoveThrottle.z /= motorDamp;

        moveDirection += MoveThrottle * SimulationRate * Time.deltaTime;

        // Gravity
        if (Controller.isGrounded && FallSpeed <= 0)
            FallSpeed = ((Physics.gravity.y * (GravityModifier * 0.002f)));
        else
            FallSpeed += ((Physics.gravity.y * (GravityModifier * 0.002f)) * SimulationRate * Time.deltaTime);

        moveDirection.y += FallSpeed * SimulationRate * Time.deltaTime;


        if (Controller.isGrounded && MoveThrottle.y <= transform.lossyScale.y * 0.001f)
        {
            // Offset correction for uneven ground
            float bumpUpOffset = Mathf.Max(Controller.stepOffset, new Vector3(moveDirection.x, 0, moveDirection.z).magnitude);
            moveDirection -= bumpUpOffset * Vector3.up;
        }

        Vector3 predictedXZ = Vector3.Scale((Controller.transform.localPosition + moveDirection), new Vector3(1, 0, 1));
        
        Controller.Move(moveDirection);
        Vector3 actualXZ = Vector3.Scale(Controller.transform.localPosition, new Vector3(1, 0, 1));

        if (predictedXZ != actualXZ)
            MoveThrottle += (actualXZ - predictedXZ) / (SimulationRate * Time.deltaTime);
    }

    public virtual void UpdateMovement()
    {
        if (EnableLinearMovement)
        {
            bool moveForward = false; //Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow);
            bool moveLeft = false; //Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow);
            bool moveRight = false; //Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow);
            bool moveBack = false; //Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow);

            bool move = false;

            move = moveForward || moveLeft || moveRight || moveBack;
            UnityEngine.XR.InputDevices.GetDeviceAtXRNode(UnityEngine.XR.XRNode.RightHand).TryGetFeatureValue(CommonUsages.primary2DAxis, out var primary2DAxis);
            if (QiyuPlatform.IsAndroid)
            {
                if (Math.Abs(primary2DAxis.x) > 0.2f || Math.Abs(primary2DAxis.y) > 0.2f)
                {
                    move = true;
                }
                else
                {
                    move = false;
                }
            }           

            MoveScale = 1.0f;

            if ((moveForward && moveLeft) || (moveForward && moveRight) ||
                (moveBack && moveLeft) || (moveBack && moveRight))
                MoveScale = 0.70710678f;

            // No positional movement if we are in the air
            if (!Controller.isGrounded || !move)
                MoveScale = 0.0f;

            MoveScale *= SimulationRate * Time.deltaTime;

            float moveInfluence = Acceleration * 0.1f * MoveScale * MoveScaleMultiplier;

            Quaternion ort = transform.rotation;
            Vector3 ortEuler = ort.eulerAngles;
            ortEuler.z = ortEuler.x = 0f;
            ort = Quaternion.Euler(ortEuler);

            if (moveForward)
                MoveThrottle += ort * (transform.lossyScale.z * moveInfluence * Vector3.forward);
            if (moveBack)
                MoveThrottle += ort * (transform.lossyScale.z * moveInfluence * BackAndSideDampen * Vector3.back);
            if (moveLeft)
                MoveThrottle += ort * (transform.lossyScale.x * moveInfluence * BackAndSideDampen * Vector3.left);
            if (moveRight)
                MoveThrottle += ort * (transform.lossyScale.x * moveInfluence * BackAndSideDampen * Vector3.right);



            moveInfluence = Acceleration * 0.1f * MoveScale * MoveScaleMultiplier;           

            // If speed quantization is enabled, adjust the input to the number of fixed speed steps.
            if (FixedSpeedSteps > 0)
            {
                primary2DAxis.y = Mathf.Round(primary2DAxis.y * FixedSpeedSteps) / FixedSpeedSteps;
                primary2DAxis.x = Mathf.Round(primary2DAxis.x * FixedSpeedSteps) / FixedSpeedSteps;
            }

            if (primary2DAxis.y > 0.0f)
                MoveThrottle += ort * (primary2DAxis.y * transform.lossyScale.z * moveInfluence * Vector3.forward);

            if (primary2DAxis.y < 0.0f)
                MoveThrottle += ort * (Mathf.Abs(primary2DAxis.y) * transform.lossyScale.z * moveInfluence *
                                       BackAndSideDampen * Vector3.back);

            if (primary2DAxis.x < 0.0f)
                MoveThrottle += ort * (Mathf.Abs(primary2DAxis.x) * transform.lossyScale.x * moveInfluence *
                                       BackAndSideDampen * Vector3.left);

            if (primary2DAxis.x > 0.0f)
                MoveThrottle += ort * (primary2DAxis.x * transform.lossyScale.x * moveInfluence * BackAndSideDampen *
                                       Vector3.right);
        }
       
    }
}
