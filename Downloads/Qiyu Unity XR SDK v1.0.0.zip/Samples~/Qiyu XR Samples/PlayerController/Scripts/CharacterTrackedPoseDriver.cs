﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SpatialTracking;

public class CharacterTrackedPoseDriver : TrackedPoseDriver
{
    public event System.Action UpdatedAnchors;

    protected override void SetLocalTransform(Vector3 newPosition, Quaternion newRotation, PoseDataFlags poseFlags)
    {
        if ((trackingType == TrackingType.RotationAndPosition || trackingType == TrackingType.RotationOnly) &&
               (poseFlags & PoseDataFlags.Rotation) > 0)
        {
            transform.rotation = newRotation;
        }

        if ((trackingType == TrackingType.RotationAndPosition || trackingType == TrackingType.PositionOnly) &&
            (poseFlags & PoseDataFlags.Position) > 0)
        {
            transform.localPosition = newPosition;
        }
        if (UpdatedAnchors != null)
            UpdatedAnchors();
    }
}
