﻿//=============================================================================
//
//          Copyright (c) 2021 Beijing iQIYI Intelligent Technologies Inc.
//                          All Rights Reserved.
//
//=============================================================================
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;

namespace Unity.XR.Qiyu
{
    public enum FoveationLevel
    {
        None = -1,
        Low = 0,
        Med = 1,
        High = 2
    }

    /// <summary>
    /// iQIYI XR SDK Manager
    /// </summary>
    public class QiyuManager : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        public static void InitQVRSDKCore()
        {
            QiyuSDKCore.Instance.Register();
        }

        private static QiyuManager instance = null;
        public static QiyuManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = FindObjectOfType<QiyuManager>();
                    if (instance == null)
                    {
                        Debug.LogWarning("QiyuManager is not exist!");
                    }
                }
                return instance;
            }
        }

        public FoveationLevel foveationLevel = FoveationLevel.None;
        public float eyeResolutionScaleFactor = 1.0f;
        //public bool trackingPosition = true;
        [HideInInspector]
        public Transform Head;

        void Awake()
        {
            instance = this;

            Head = Camera.main.transform;
        }

        private void Start()
        {
            XRSettings.eyeTextureResolutionScale = eyeResolutionScaleFactor;
            Utils.SetFoveationLevel((int)foveationLevel);
        }

        public void Recenter()
        {
            UnityEngine.XR.InputDevices.GetDeviceAtXRNode(UnityEngine.XR.XRNode.Head).subsystem.TryRecenter();
        }
    }
}
