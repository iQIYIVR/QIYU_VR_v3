﻿//=============================================================================
//
//          Copyright (c) 2021 Beijing iQIYI Intelligent Technologies Inc.
//                          All Rights Reserved.
//
//=============================================================================
using UnityEngine;

namespace Unity.XR.Qiyu
{
    public class QiyuSDKCore : QiyuSingletion<QiyuSDKCore>
    {
        bool running = false;

        public override void Awake()
        {
            base.Awake();
            if (QiyuPlatform.IsAndroid)
            {
                AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
                AndroidJavaObject activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");

                QiyuPlugin.QiyuSDKCorePlugins.QVR_Init(
                    activity.GetRawObject(),
                    SystemInfo.graphicsMultiThreaded == true ? 1 : 0,
                    QiyuMessageManager.RequestProcess_Ptr,
                    QiyuMessageManager.ListenerProcess_Ptr);

                Debug.Log("QiyuSDKCore QVR_Awake");
            }
            running = true;
        }

        public void OnDestroy()
        {
            Debug.Log("QiyuSDKCore OnDestroy");
            QiyuInput.OnDestroy();
        }

        public void Start()
        {
            Debug.Log("QiyuSDKCore Start");
            QiyuInput.Start();
        }

        public void Update()
        {
            if (running == false) return;
            if (QiyuPlatform.IsAndroid)
            {
                QiyuPlugin.QiyuSDKCorePlugins.QVR_Update(Time.deltaTime);
            }

            QiyuInput.Update();
        }

        public void OnApplicationPause(bool pause)
        {
            Debug.Log("QiyuSDKCore OnApplicationPause:" + pause);

            if (running == false) return;
            if (QiyuPlatform.IsAndroid)
                QiyuPlugin.QiyuSDKCorePlugins.QVR_OnApplicationPause(pause);

            QiyuInput.OnApplicationPause(pause);
        }
    }
}
