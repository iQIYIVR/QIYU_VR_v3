﻿//=============================================================================
//
//          Copyright (c) 2021 Beijing iQIYI Intelligent Technologies Inc.
//                          All Rights Reserved.
//
//=============================================================================
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

using FunPtr = System.IntPtr;
using DataPtr = System.IntPtr;
using System.Text;

namespace Unity.XR.Qiyu
{
    public class RequestCallback
    {
        public RequestCallback() { }

        public virtual void HandleRequestMessage(DataPtr ret, int size)
        {

        }
    }
    public class RequestCallbackByVoid : RequestCallback
    {
        protected Action callBack;
        public RequestCallbackByVoid(Action callBack)
        {
            this.callBack = callBack;
        }
        public static RequestCallback Create(Action callBack)
        {
            RequestCallback rcb = new RequestCallbackByVoid(callBack);
            return rcb;
        }

        public override void HandleRequestMessage(DataPtr data, int size)
        {
            callBack?.Invoke();
        }
    }
    /// <summary>
    /// 返回Json格式数据
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class RequestCallbackByJson<T> : RequestCallback
    {
        protected Action<T> callBack;

        public RequestCallbackByJson(Action<T> callBack)
        {
            this.callBack = callBack;
        }

        public static RequestCallback Create(Action<T> callBack)
        {
            RequestCallback rcb = new RequestCallbackByJson<T>(callBack);
            
            return rcb;
        }

        public override void HandleRequestMessage(DataPtr data, int size)
        {
            byte[] buffer = new byte[size];
            Marshal.Copy(data, buffer, 0, size);
            string msg = Encoding.UTF8.GetString(buffer);
            Debug.Log("RequestCallbackByJson::HandleMessage=" + msg);
            T obj = QVRUtils.FromJson<T>(msg);
            callBack?.Invoke(obj);
  
        }
    }

    public interface IRequestCallbackData<T>
    {
        T ParseData(DataPtr ret);
    }

    /// <summary>
    /// 返回二进制数据
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class RequestCallbackByBit<T> : RequestCallback
    {
        protected Action<T> callBack;

        public RequestCallbackByBit(Action<T> callBack)
        {
            this.callBack = callBack;
        }

        public static RequestCallback Create(Action<T> callBack)
        {
            RequestCallback rcb = new RequestCallbackByBit<T>(callBack);
            return rcb;
        }

        public override void HandleRequestMessage(DataPtr ret, int size)
        {
      
        }
    }

    public class RequestID
    {
        static ulong id = 0;
        public static ulong ID{
            get { return ++id; }
         }
    }

        
    public class QiyuMessageManager
    {
        static Dictionary<ulong, RequestCallback> requestCallbackList = new Dictionary<ulong, RequestCallback>();
        static Dictionary<ulong, RequestCallback> listenerCallbackList = new Dictionary<ulong, RequestCallback>();
   
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate void CallBack(ulong messageId, DataPtr result, int size);

        static QiyuMessageManager()
        {
            RegisterListener();
        }

        public static FunPtr RequestProcess_Ptr
        {
            get {
                CallBack callback_delegate = MessageProcess;
                return Marshal.GetFunctionPointerForDelegate(callback_delegate);
            }
        }

        public static FunPtr ListenerProcess_Ptr
        {
            get
            {
                CallBack callback_delegate = ListenerProcess;
                return Marshal.GetFunctionPointerForDelegate(callback_delegate);
            }
        }

        [AOT.MonoPInvokeCallback(typeof(CallBack))]
        public static void MessageProcess(ulong requestId, DataPtr result, int size)
        {
            if (requestCallbackList.ContainsKey(requestId))
            {
                try
                {
                    requestCallbackList[requestId].HandleRequestMessage(result, size);
                }
                catch (Exception e)
                {
                    Debug.LogError(e.Message);
                }
                finally
                {
                    requestCallbackList.Remove(requestId);
                }
            }
        }

        public static ulong AddRequest( RequestCallback rcb)
        {
            ulong requestID = RequestID.ID;
            requestCallbackList[requestID] = rcb;
            return requestID;
        }

        [AOT.MonoPInvokeCallback(typeof(CallBack))]
        public static void ListenerProcess(ulong messageCode, DataPtr result, int size)
        {
            try
            {
                Debug.Log("ListenerProcess " + messageCode);
                if (listenerCallbackList.ContainsKey(messageCode))
                {

                    listenerCallbackList[messageCode].HandleRequestMessage(result, size);
                }
            }
            catch (Exception e)
            {
                Debug.LogError(e.Message);
            }
        }

        public static void AddRequest(MessageCode messageCode, RequestCallback rcb)
        {
            if (!listenerCallbackList.ContainsKey((ulong)messageCode))
            {
                listenerCallbackList[(ulong)messageCode] = rcb;
            }
            else
            {
                Debug.LogError("MessageCode.AddRequest Error");
            }
    
        }

        private static void RegisterListener()
        {
            AddRequest(MessageCode.QiyuSdkInit,
                   RequestCallbackByJson<QiyuPlugin.MessageResult<QiyuPlugin.SDKInit>>.Create((QiyuPlugin.MessageResult<QiyuPlugin.SDKInit> ret) =>
                   {
                       Debug.Log("MessageRet_SDKInit =" + ret.IsSuccess() );
                       QiyuMessageListener.Trigger(MessageCode.QiyuSdkInit, ret);
                   })
                );

        }
    }
}

