﻿//=============================================================================
//
//          Copyright (c) 2021 Beijing iQIYI Intelligent Technologies Inc.
//                          All Rights Reserved.
//
//=============================================================================
using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

using FunPtr = System.IntPtr;
using DataPtr = System.IntPtr;
using StringPtr = System.IntPtr;

namespace Unity.XR.Qiyu
{
    public static partial class QiyuPlugin
    {
        public class QiyuSDKCorePlugins
        {
            private const string pluginName = "qiyivrsdkcore";

            //------------------------------------------------------------------------

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_Init(IntPtr activity, int isMultiThreadedRender, FunPtr funPtr_request, FunPtr funPtr_listener);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_Update(float deltaTime);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_OnApplicationPause(bool pause);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_SendHomeEvent();
            /// ----------------------------------------------------------------------------

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern Bool QVR_GetBoundaryConfigured();
            
            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern BoundaryTestResult QVR_TestBoundaryPoint(Vector3f point, BoundaryType boundaryType);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_GetOriginAxis(ref Vector3f pos, ref Quatf rot);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern Bool QVR_GetBoundaryGeometry(BoundaryType boundaryType, IntPtr points, ref int pointsCount);
            
            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern Vector3f QVR_GetBoundaryDimensions(BoundaryType boundaryType);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern Bool QVR_GetBoundaryVisible();

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern Bool QVR_SetBoundaryVisible(Bool value);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern Bool QVR_RegisterBoundaryChangedCallback(FunPtr callback);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern Bool QVR_UnRegisterBoundaryChangedCallback(FunPtr callback);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_TestMessageCallBack(ulong requestID, string param);

            #region controller
            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_GetControllerDate(ref ControllerData left, ref ControllerData right);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern Bool QVR_GetControllerIsInit();
            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_ControllerBeginServer();

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_ControllerEndServer();

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_ControllerSendMsg(string cmd);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_ControllerStartVibration(int deviceId, int amplitude, int duration);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_ControllerSetType(int type);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern int QVR_ControllerGetType();

            #endregion

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern string QVR_TestString(string param);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_InitQiyuSDK(string app_id, string developer_id, string app_secret, string sign_key);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_GetAppUpdateInfo(ulong requestID, string app_id, string curVersion);
            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern int QVR_IsAccountLogin();

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_GetQiyuAccountInfo(ulong requestID);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_LaunchOtherApp(string app_id, string key, string value);
            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_LaunchHome(string key, string value);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern void QVR_GetDeepLink(ulong requestID);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern int QVR_GetHand();

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern int QVR_SetHand(int type);

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern int QVR_GetFoveatEnable();

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern float QVR_GetFloorLevel();

            [DllImport(pluginName, CallingConvention = CallingConvention.Cdecl)]
            public static extern int QVR_GetUserIPD();

            //svrplugin
            [DllImport("svrplugin", CallingConvention = CallingConvention.Cdecl)]
            public static extern int SvrSetExtraLatencyMode(bool mode);

        }
    }

}
