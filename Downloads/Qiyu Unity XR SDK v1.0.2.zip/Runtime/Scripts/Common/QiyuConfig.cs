﻿//=============================================================================
//
//          Copyright (c) 2021 Beijing iQIYI Intelligent Technologies Inc.
//                          All Rights Reserved.
//
//=============================================================================
using UnityEngine;

namespace Unity.XR.Qiyu
{
    /// <summary>
    /// sdk的一些参数设置
    /// </summary>
    public class QiyuConfig
    {
        /// <summary>
        /// 场景中Renderer渲染层级，数值越高优先级越高
        /// </summary>
        public class RenderOrderConfig
        {
            /// <summary>
            /// 光标的渲染层级
            /// </summary>
            public static readonly int POINTER_ORDER = 1000;

            /// <summary>
            /// 遥控器模型的渲染层级
            /// </summary>
            public static readonly int CONTROLLER_MODEL_ORDER = 3000;

            /// <summary>
            /// 输入法键盘的渲染层级
            /// </summary>
            public static readonly int KEYBOARD_CANVAS_ORDER = 100;
        }

        /// <summary>
        /// 和ArmModel相关的配置
        /// </summary>
        public class ArmModelConfig
        {
            /// <summary>
            /// 遥控器光标向下自然倾斜的角度，取值范围[0, 30]
            /// </summary>
            public static readonly float POINTER_TILT_ANGLE = 15.0f;

            /// <summary>
            /// 胳膊肘的高度，范围[0, 0.2]，单位m
            /// </summary>
            public static readonly float ADDED_ELBOW_HEIGHT = 0.0f;

            /// <summary>
            /// 胳膊肘的深度，范围[0, 0.2]，单位m
            /// </summary>
            public static readonly float ADDED_ELBOW_DEPTH = 0.0f;

            /// <summary>
            /// 是否使用遥控器的加速计
            /// </summary>
            public static readonly bool USE_ACCERLEROMETER = false;
        }

        /// <summary>
        /// 输入模块相关的配置
        /// </summary>
        public class InputModuleConfig
        {
            /// <summary>
            /// 光标默认的距离（在没有检测到物体时光标的距离）
            /// </summary>
            public static readonly float POINTER_DEFAULT_DISTANCE = 15;

            /// <summary>
            /// 按钮长按间隔
            /// </summary>
            public static readonly float LONG_PRESS_TIME = 1.2f;

            /// <summary>
            /// 光标偏移
            /// </summary>
            public static readonly float POINTER_OFFSET = 0.25f;

            /// <summary>
            /// 默认射线长度
            /// </summary>
            public static readonly float LASER_DEFAULT_LENGTH = 1f;
        }

        /// <summary>
        /// 视线方向的射线检测的物体的layer，区别于InputModule，用于用户视线和物体的交互

        /// <see cref="IGazeInteractive">IGazeInteractive</see>定义了该交互的实现方式, 
        /// 需要响应该交互的物体需要实现接口并将其layer设置成该值
        /// </summary>
        public static readonly LayerMask GAZE_STANDALONE_RAYCAST_LAYERMASK = 20;
    }
}

