﻿//=============================================================================
//
//          Copyright (c) 2021 Beijing iQIYI Intelligent Technologies Inc.
//                          All Rights Reserved.
//
//=============================================================================
namespace Unity.XR.Qiyu
{
    public class Version
    {
        public static string svr_version = "3.0.1";
        public static string controller_version = "1.0.3";
        public static string svr_modify_version = "1.0.11";
    }

    public enum KEY_STATUS
    {
        UP = 0,
        DOWN = 1,
        Touch = 3,
        NoTouch = 4,
        NONE
    }
    public enum DEVICE_ID
    {
        // HEAD,
        HAND_0 = 0x01,
        HAND_1 = 0x02,
        HAND_0_1 = 0x03
    }

    public class CMDKey
    {
        public static string KEY_VERSION = "VERSION";
        public static string KEY_BATTERY = "BATTERY";
        public static string KEY_CONNECTION = "CONNECTION";
        public static string KEY_ALL_CONTROLLER_STATUS = "ALL_CONTROLLER_STATUS";
        public static string KEY_POSITION = "POSITION";
        public static string KEY_QUATERNION = "QUATERNION";
        public static string KEY_POSE = "POSE";
        public static string KEY_VIBRATE = "VIBRATE";
        public static string KEY_RECENTER = "RECENTER";
        public static string KEY_START_PAIRING = "STARTPAIRING";
        public static string KEY_CLEAR_PAIRING = "CLEARPAIRING";
    }


}


