﻿using Qiyi.UI.InputField;
using Unity.XR.Qiyu;
using UnityEngine;
using UnityEngine.UI;

public class QVRDemo : MonoBehaviour
{
    // Start is called before the first frame update
    public Text uid;
    public Text name;
    public Text pic;
    public VrInputField targetAppID;
    Transform btnListGO;

    private void Awake()
    {
        btnListGO = transform.Find("MainCanvasTROnce/MainCanvasOnce/MainButtons");

        Button GetAccountInfo_btn = btnListGO.Find("GetAccountInfo").GetComponent<Button>();
        GetAccountInfo_btn.onClick.AddListener(GetIQIYIAccountInfo);

        Button GoHomeLogin_btn = btnListGO.Find("GoHomeLogin").GetComponent<Button>();
        GoHomeLogin_btn.onClick.AddListener(GoHomeLogin);

        Button OpenApp_btn = btnListGO.Find("OpenApp").GetComponent<Button>();
        OpenApp_btn.onClick.AddListener(OpenApp);

    }

    void Start()
    {

        if (!QiyuPlatform.IsAndroid) return;

        QiyuPlugin.GetDeepLink(
        RequestCallbackByJson<QiyuPlugin.MessageResult<QiyuPlugin.DeepLinkParam>>.Create((QiyuPlugin.MessageResult<QiyuPlugin.DeepLinkParam> ret) =>
        {

        }));

        //First, you need to monitor the SDK initialization result
        QiyuMessageListener.AddListener(MessageCode.QiyuSdkInit, ret =>
        {
            QiyuPlugin.MessageResult<QiyuPlugin.SDKInit> msg = ret[0] as QiyuPlugin.MessageResult<QiyuPlugin.SDKInit>;
            if (msg.IsSuccess())
            {

            }

        });

        //First, you need to monitor the SDK initialization result
        QiyuMessageListener.AddListener(MessageCode.QiyuSdkInit, ret =>
        {
            QiyuPlugin.MessageResult<QiyuPlugin.SDKInit> msg = ret[0] as QiyuPlugin.MessageResult<QiyuPlugin.SDKInit>;
            if (msg.IsSuccess())
            {
                QiyuPlugin.GetAppUpdateInfo(
                    "70519169",
                    "1",
                   RequestCallbackByJson<QiyuPlugin.MessageResult <QiyuPlugin.AppUpdateInfo>>.Create((QiyuPlugin.MessageResult<QiyuPlugin.AppUpdateInfo> msg1) =>
                   {
                       if (msg1.IsSuccess())
                       {
                     
                       } 
                   }));
            }

        });

        //Initialize SDK
        QiyuPlugin.InitQiyuSDK(
            "70519169", //APPID 从开发者后台获取
            "820903",   //DeveloperID 从开发者后台获取
            "04c8f3a2d398a09debdb34902f278e2a", //App秘钥 从开发者后台获取
            "bc85d655c3416d5abdd98d4f7184fa22");//App接口签名Key 从开发者后台获取

        QiyuPlugin.GetDeepLink(
        RequestCallbackByJson<QiyuPlugin.MessageResult<QiyuPlugin.DeepLinkParam>>.Create((QiyuPlugin.MessageResult<QiyuPlugin.DeepLinkParam> ret) =>
        {
            Debug.Log("QVRDemo GetDeepLink=" + ret.ToString());
        }));
    }

    public void OnApplicationPause(bool pause)
    {
        if (pause == false)
        {

        }
    }
    public void GoHomeLogin()
    {
        QiyuPlugin.LaunchHome("login", "");

    }

    // Get Qiyu Account information
    public void GetIQIYIAccountInfo()
    {
        if (QiyuPlugin.IsQiyuAccountLogin())
        {
            QiyuPlugin.GetQiyuAccountInfo(
           RequestCallbackByJson<QiyuPlugin.MessageResult<QiyuPlugin.QiyuAccountInfo>>.Create((QiyuPlugin.MessageResult<QiyuPlugin.QiyuAccountInfo> msg) =>
           {
               if (msg.IsSuccess())
               {
                   uid.text = msg.data.uid;
                   name.text = msg.data.name;
                   pic.text = msg.data.icon;
               }
           }));
        }
        else {
            //跳转到Home进行登录
            QiyuPlugin.LaunchHome("login", "");
        }
    }

    public void OpenApp()
    {
        string appID = targetAppID.text;
        if (string.IsNullOrEmpty(appID))
        {
            appID = "65302330";
        }
        QiyuPlugin.LaunchOtherApp(appID, "key", "value");
    }
}
