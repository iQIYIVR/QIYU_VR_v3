﻿using System.Collections.Generic;
using Unity.XR.Qiyu;
using UnityEngine;
using UnityEngine.XR;

public class ButtonTest : MonoBehaviour
{
    InputDevice contrllerR;
    InputDevice headController;
    InputDevice contrllerL;

    float m_AxisToPressThreshold = 0.5f;

    public GameObject dbugGameObj;

    Dictionary<string, DebugText> DebugText_Dic = new Dictionary<string, DebugText>();

    public Transform headInfoRoot;
    public Transform leftControllerInfoRoot;
    public Transform rightControllerInfoRoot;

    public void Start()
    {
        var inputDevices = new List<InputDevice>();
        InputDevices.GetDevices(inputDevices);
        var usage = new List<InputFeatureUsage>();
        
        foreach (var device in inputDevices)
        {
            Debug.Log(string.Format("Device found with name '{0}' and role '{1}'", device.name, device.role.ToString()));

            if (device.role == InputDeviceRole.RightHanded)
            {
                contrllerR = device;
                if (contrllerR.TryGetFeatureValue(CommonUsages.batteryLevel, out var batteryLevel))
                    Debug.Log("TestHandR_batteryLevel:" + batteryLevel);//显示手柄电量
            }
            else if (device.role == InputDeviceRole.Generic)
            {
                headController = device;
            }
            if (device.role == InputDeviceRole.LeftHanded)
            {
                contrllerL = device;
                if (contrllerL.TryGetFeatureValue(CommonUsages.batteryLevel, out var batteryLevel))
                    Debug.Log("TestHandL_batteryLevel:" + batteryLevel);
            }
        }   
    }

    public void AddDebugText(string name, string info,Transform root)
    {
        if (DebugText_Dic.ContainsKey(name))
        {
            DebugText_Dic[name].SetText(info);
        }
        else
        {
            GameObject obj = Instantiate(dbugGameObj);
            obj.transform.parent = root;
            obj.transform.localPosition = Vector3.zero;
            obj.transform.localScale = Vector3.one;
            obj.transform.localRotation = Quaternion.EulerRotation(Vector3.zero);
            obj.name = name;

            DebugText debugShow = obj.GetComponent<DebugText>();
            debugShow.SetText(info);
            DebugText_Dic.Add(name, debugShow);
        }
    }

    float delte = 0;
    int flag = 0;
    //float[] amplit = { 0.5f, 0.33f, 0.333f ,0.2f};
    int[] amplit = { 7, 5, 6, 4 };
    int time = 0;
    bool lastState_trigger = false;
    private void Update()
    {
        //down和up触发一次的用例
        if (contrllerR.TryGetFeatureValue(CommonUsages.triggerButton, out var curState_trigger))
        {
            if (lastState_trigger != curState_trigger)
            {
                if (curState_trigger)
                {
                    Debug.Log("trigger down!");
                }
                else
                {
                    Debug.Log("trigger up!");
                }
            }
            lastState_trigger = curState_trigger;
        }

        AddDebugText("Head Controller isValid", headController.isValid.ToString(), headInfoRoot);
        if (headController.TryGetFeatureValue(CommonUsages.devicePosition, out var head_devicePosition))
        {
            AddDebugText("Head Controller devicePosition", head_devicePosition.ToString(), headInfoRoot);
        }
        if (headController.TryGetFeatureValue(CommonUsages.deviceRotation, out var head_deviceRotation))
        {
            AddDebugText("Head Controller deviceRotation", head_deviceRotation.ToString(), headInfoRoot);
        }

        AddDebugText("Display rate:", XRDevice.refreshRate.ToString(), headInfoRoot);


        AddDebugText("Right Controller is Valid", contrllerR.isValid.ToString(),rightControllerInfoRoot);       
        AddDebugText("Right Controller name is", contrllerR.name, rightControllerInfoRoot);
        AddDebugText("Right Controller serialNumber is",contrllerR.serialNumber, rightControllerInfoRoot);
        AddDebugText("Right Controller manufacturer is", contrllerR.manufacturer, rightControllerInfoRoot);
        AddDebugText("Right Controller characteristics is", contrllerR.characteristics.ToString(), rightControllerInfoRoot);

        AddDebugText("Left Controller is Valid", contrllerL.isValid.ToString(), leftControllerInfoRoot);
        AddDebugText("Left Controller name is", contrllerL.name, leftControllerInfoRoot);
        AddDebugText("Left Controller serialNumber is", contrllerL.serialNumber, leftControllerInfoRoot);
        AddDebugText("Left Controller manufacturer is", contrllerL.manufacturer, leftControllerInfoRoot);
        AddDebugText("Left Controller characteristics is", contrllerL.characteristics.ToString(), leftControllerInfoRoot);

        //delte += Time.deltaTime;
        ////测试震动相关
        //if (delte > 10 )
        //{
        //    if (contrllerR.TryGetHapticCapabilities(out HapticCapabilities capabilities))
        //    {
        //        AddDebugText("HapticImpulsemaxSize", capabilities.bufferMaxSize.ToString());
        //        AddDebugText("HapticImpulsemFreq",capabilities.bufferFrequencyHz.ToString());
        //        AddDebugText("HapticImpulseOptimalSize" ,capabilities.bufferOptimalSize.ToString());
        //        AddDebugText("HapticImpulsenumChannels" ,capabilities.numChannels.ToString());
        //        AddDebugText("HapticImpulsesupportsBuffer" , capabilities.supportsBuffer.ToString());
        //        AddDebugText("HapticImpulsesupportsImpulse" , capabilities.supportsImpulse.ToString());
        //    }
        //    bool SendRightHandHapticSuccess = contrllerR.SendHapticImpulse(1, amplit[time % amplit.Length], 5);
        //    bool SendLeftHandHapticSuccess = contrllerL.SendHapticImpulse(1, amplit[time % amplit.Length], 5);
        //    flag = 1;          
        //    AddDebugText("amplit is ", amplit[time % amplit.Length].ToString());
        //    time += 1;
        //    delte = 0;
        //}

        //速度相关包括速度，加速度，角速度等

        if (contrllerR.TryGetFeatureValue(CommonUsages.deviceAcceleration, out var deviceAcceleration)) {
            AddDebugText("Right Hand device Acceleration is",deviceAcceleration.ToString("F6"),rightControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.deviceAcceleration, out var deviceAccelerationl)) {
            AddDebugText("Left Hand device Acceleration is:",deviceAccelerationl.ToString("F6"),leftControllerInfoRoot);
        }
        if (contrllerR.TryGetFeatureValue(CommonUsages.deviceAngularAcceleration, out var deviceAngularAcceleration)) {
            AddDebugText("Right Hand device Angular Acceleration is ",deviceAngularAcceleration.ToString("F6"),rightControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.deviceAngularAcceleration, out var deviceAngularAccelerationl)) {
            AddDebugText("TestHandL_deviceAngularAcceleration:",deviceAngularAccelerationl.ToString("F6"), leftControllerInfoRoot);
        }
        if (contrllerR.TryGetFeatureValue(CommonUsages.deviceAngularVelocity, out var deviceAngularVelocity)) {
            AddDebugText("TestHandR_deviceAngularVelocity:",deviceAngularVelocity.ToString("F6"), rightControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.deviceAngularVelocity, out var deviceAngularVelocityl)) {
            AddDebugText("TestHandL_deviceAngularVelocity:",deviceAngularVelocityl.ToString("F6"), leftControllerInfoRoot);
        }
        if (contrllerR.TryGetFeatureValue(CommonUsages.devicePosition, out var devicePosition)) {
            AddDebugText("TestHandR_devicePosition:",devicePosition.ToString("F6"), rightControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.devicePosition, out var devicePositionl)) {
            AddDebugText("TestHandL_devicePosition:",devicePositionl.ToString("F6"), leftControllerInfoRoot);
        }
        if (contrllerR.TryGetFeatureValue(CommonUsages.deviceRotation, out var deviceRotation)) {
            AddDebugText("TestHandR_deviceRotation:",deviceRotation.ToString("F6"), rightControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.deviceRotation, out var deviceRotationl)) {
            AddDebugText("TestHandL_deviceRotation:",deviceRotationl.ToString("F6"), leftControllerInfoRoot);
        }
        if (contrllerR.TryGetFeatureValue(CommonUsages.deviceVelocity, out var deviceVelocity)) {
            AddDebugText("TestHandR_deviceVelocity:",deviceVelocity.ToString("F6"), rightControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.deviceVelocity, out var deviceVelocityl)) {
            AddDebugText("TestHandL_deviceVelocity:",deviceVelocityl.ToString("F6"), leftControllerInfoRoot);
        }

        //右手键值
        if (contrllerR.TryGetFeatureValue(CommonUsages.grip, out var grip))
        {
            AddDebugText("TestHandR_grip:", grip.ToString(), rightControllerInfoRoot);
        }
        if (contrllerR.TryGetFeatureValue(CommonUsages.gripButton, out var gripButton))
        {
            AddDebugText("TestHandR_gripButton:", gripButton.ToString(), rightControllerInfoRoot);
        }       
        if (contrllerR.TryGetFeatureValue(CommonUsages.menuButton, out var menuButton))
        {
            AddDebugText("TestHandR_menuButton:", menuButton.ToString(), rightControllerInfoRoot);
        }
        if (contrllerR.TryGetFeatureValue(CommonUsages.primary2DAxis, out var primary2DAxis))
        {
            AddDebugText("TestHandR_primary2DAxis:", primary2DAxis.ToString(), rightControllerInfoRoot);
        }
        if (contrllerR.TryGetFeatureValue(CommonUsages.primary2DAxisClick, out var primary2DAxisClick))
        {
            AddDebugText("TestHandR_primary2DAxisClick:", primary2DAxisClick.ToString(), rightControllerInfoRoot);
        }
        if (contrllerR.TryGetFeatureValue(CommonUsages.primary2DAxisTouch, out var primary2DAxisTouch))
        {
            AddDebugText("TestHandR_primary2DAxisTouch:", primary2DAxisTouch.ToString(), rightControllerInfoRoot);
        }
        if (contrllerR.TryGetFeatureValue(CommonUsages.primaryButton, out var primaryButton))
        {
            AddDebugText("TestHandR_primaryButton:", primaryButton.ToString(), rightControllerInfoRoot);
        }
        if (contrllerR.TryGetFeatureValue(CommonUsages.primaryTouch, out var primaryTouch))
        {
            AddDebugText("TestHandR_primaryTouch:", primaryTouch.ToString(), rightControllerInfoRoot);
        }
        if (contrllerR.TryGetFeatureValue(CommonUsages.secondaryButton, out var secondaryButton))
        {
            AddDebugText("TestHandR_secondaryButton:", secondaryButton.ToString(), rightControllerInfoRoot);
        }
        if (contrllerR.TryGetFeatureValue(CommonUsages.secondaryTouch, out var secondaryTouch))
        {
            AddDebugText("TestHandR_secondaryTouch:", secondaryTouch.ToString(), rightControllerInfoRoot);
        }
        if (contrllerR.TryGetFeatureValue(CommonUsages.trigger, out var trigger))
        {
            AddDebugText("TestHandR_trigger:", trigger.ToString(), rightControllerInfoRoot);
        }
        if (contrllerR.TryGetFeatureValue(CommonUsages.triggerButton, out var triggerButton))
        {
            AddDebugText("TestHandR_triggerButton:", triggerButton.ToString(), rightControllerInfoRoot);
        }        
        if (contrllerR.TryGetFeatureValue(QiyuUsages.triggerTouch, out var triggerTouch))
        {
            AddDebugText("TestHandR_Trigger Touch:", triggerTouch.ToString(), rightControllerInfoRoot);
        }


        //左手柄键值相关1
        if (contrllerL.TryGetFeatureValue(CommonUsages.grip, out var grip_L)) {
            AddDebugText("TestHandL_grip:", grip_L.ToString(), leftControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.gripButton, out var gripButton_L))
        {
            AddDebugText("TestHandL_gripButton:", gripButton_L.ToString(), leftControllerInfoRoot);
        }       
        if (contrllerL.TryGetFeatureValue(CommonUsages.menuButton, out var menuButton_L))
        {
            AddDebugText("TestHandL_menuButton:", menuButton_L.ToString(), leftControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.primary2DAxis, out var primary2DAxis_L))
        {
            AddDebugText("TestHandL_primary2DAxis:", primary2DAxis_L.ToString(), leftControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.primary2DAxisClick, out var primary2DAxisClick_L))
        {
            AddDebugText("TestHandL_primary2DAxisClick:" , primary2DAxisClick_L.ToString(), leftControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.primary2DAxisTouch, out var primary2DAxisTouch_L))
        {
            AddDebugText("TestHandL_primary2DAxisTouch:", primary2DAxisTouch_L.ToString(), leftControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.primaryButton, out var primaryButton_L))
        {
            AddDebugText("TestHandL_primaryButton:" , primaryButton_L.ToString(), leftControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.primaryTouch, out var primaryTouch_L))
        {
            AddDebugText("TestHandL_primaryTouch:", primaryTouch_L.ToString(), leftControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.secondaryButton, out var secondaryButton_L))
        {
            AddDebugText("TestHandL_secondaryButton:", secondaryButton_L.ToString(), leftControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.secondaryTouch, out var secondaryTouch_L))
        {
            AddDebugText("TestHandL_secondaryTouch:", secondaryTouch_L.ToString(), leftControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.trigger, out var trigger_L))
        {
            AddDebugText("TestHandL_trigger:", trigger_L.ToString(), leftControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(CommonUsages.triggerButton, out var triggerButton_L))
        {
            AddDebugText("TestHandL_triggerButton:", triggerButton_L.ToString(), leftControllerInfoRoot);
        }
        if (contrllerL.TryGetFeatureValue(QiyuUsages.triggerTouch, out var triggerTouch_L))
        {
            AddDebugText("TestHandL_Trigger Touch:", triggerTouch_L.ToString(), leftControllerInfoRoot);
        }

        if (contrllerR.TryGetFeatureValue(CommonUsages.deviceRotation, out var hand_R_deviceRotation))
        {
            AddDebugText("Hand right Controller deviceRotation", hand_R_deviceRotation.ToString(), rightControllerInfoRoot);
        }

        if (contrllerL.TryGetFeatureValue(CommonUsages.deviceRotation, out var hand_L_deviceRotation))
        {
            AddDebugText("Hand left Controller deviceRotation", hand_L_deviceRotation.ToString(), leftControllerInfoRoot);
        }

        if (contrllerR.TryGetFeatureValue(CommonUsages.devicePosition, out var hand_R_devicePosition))
        {
            AddDebugText("Hand right Controller devicePosition", hand_R_devicePosition.ToString(), rightControllerInfoRoot);
        }

        if (contrllerL.TryGetFeatureValue(CommonUsages.devicePosition, out var hand_L_devicePosition))
        {
            AddDebugText("Hand left Controller devicePosition", hand_L_devicePosition.ToString(), leftControllerInfoRoot);
        }



    }
}
